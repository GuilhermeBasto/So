/* CREATED BY:
 * 
 * Diogo Martins 2013133962
 * José Ferreira 2014192844

 * Sistemas Operativos 2016/2017
 */
 
#include <stdio.h>
#include <sys/types.h> 
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <ctype.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <sys/shm.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <time.h>
#include <pthread.h>
#include <errno.h>
#include <semaphore.h>
#include <fcntl.h>
#define PIPE_NAME "np_client_server"

void create_namedpipe_client();
void catch_ctrlc(int);
int fd,flag;

int main(){
	signal(SIGINT,catch_ctrlc);
	create_namedpipe_client();
	return 0;
}

void create_namedpipe_client(){
 
 char command[100];

 if ((fd = open(PIPE_NAME, O_WRONLY)) < 0) {     
 	perror("Cannot open pipe for writing: ");     
 	exit(0);  
 }

while(1){
 	scanf("%s",command);
 	/*if(flag!=2){
 		if(strcmp(command,"threads")!=0 && strcmp(command,"scheduling")!=0 && strcmp(command,"allowed")!=0 ){
 			fflush(stdin);
 			printf("Command not recognized!\n");
 			flag++;
 			continue;
 		}
 		if(flag==2){
 			flag=0;
 		}*/
 	printf("[CLIENT] Sending command <%s> \n",command);     
 	write(fd, command, 200); 
	command[0]='\0';
	} 	
	
} 



void catch_ctrlc(int sig){
	//Cleanup
	write(fd,"Closed",100);
	close(fd);        
	printf("Client terminating\n");
	exit(0);
}
