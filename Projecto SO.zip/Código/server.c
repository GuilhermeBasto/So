/* CREATED BY:
 * 
 * Diogo Martins 2013133962 120 horas
 * José Ferreira 2014192844 115 horas



 * Sistemas Operativos 2016/2017
 */



#define _GNU_SOURCE 1
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include <semaphore.h>
#include <sys/ipc.h> 
#include <sys/shm.h>
#include <sys/fcntl.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <time.h>
#include <string.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <ctype.h>
#include <sys/stat.h>
#include <signal.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/mman.h>
#include <linux/mman.h>
// Produce debug information
#define DEBUG	  	1	

// Header of HTTP reply to client 
#define	SERVER_STRING 	"Server: simpleserver/0.1.0\r\n"
#define HEADER_1	"HTTP/1.0 200 OK\r\n"
#define HEADER_2	"Content-Type: text/html\r\n\r\n"

#define GET_EXPR	"GET /"
#define CGI_EXPR	"cgi-bin/"
#define SIZE_BUF	1024

#define DEFAULT_THREADS 5

#define PIPE_NAME   "np_client_server"
#define	FILE_MODE	(S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH)


//##################################################### STRUCTS DECLARATION ##############################################
// Configurations Structure
 typedef struct allowed{
 	char* name;
 	struct allowed * next;
 }allowed;

 typedef struct config{
 	int s_port;
 	int scheduling;
 	int thread_pool;
 	allowed* files;
 }config;

//Buffer Structure

 typedef struct request* rptr;
 typedef struct request{
 	char req[SIZE_BUF];
 	int socket;
 	int compressed;
 	clock_t s_time;
 	char st_info[100];	
	char et_info[100];
 	rptr next;
 }request;

//Statitics Structure

 typedef struct statistics{
 	int n_static;
 	int n_compressed;
 	double at_compressed;
 	double at_static;
 }statistics;

 typedef struct statistics_request{
 	int type;
 	char name[100];
 	clock_t s_time;
 	clock_t e_time;
 	char st_info[100];
 	char et_info[100];
 	int count;
 }statistics_request;



	//##################################################### FUNCTIONS PROTOTYPE DECLARATION ##############################################
void find_buff(rptr buffer, int socket,rptr *previous, rptr *actual);
int  fireup(int port);
void identify(int socket);
void get_request(int socket);
int  read_line(int socket, int n);
void send_header(int socket);
void send_page(rptr aux_conn);
void execute_script(int socket);
void not_found(int socket);
void catch_ctrlc(int);
void cannot_execute(int socket);
void * worker(void * t);
void * scheduler(void * t);
void init();
void initialConfig();
void buffer_add(rptr buffer,int socket);
void create_process();				
void create_threads(int thread_id[],int flag);
void* create_namedpipe_server();
void buffer_remove(rptr buffer,int pos);
rptr create_buffer(void);
rptr select_request(rptr buffer,rptr aux_conn);
void find_buff_type(rptr buffer, int type,rptr *previous, rptr *actual);
void stats_manager();
time_t get_time();
void sighandler_stats(int sig);
void sighandler_stats2(int sig);


 	//##################################################### GLOBAL VARIABLES DECLARATION ##############################################

sem_t sem;
sem_t semmmf;
sem_t waitsem;
sem_t statssem;
sem_t reqsem;
statistics *stats;
statistics_request *statsreq;
config *cfg;
rptr buffer;	
FILE *fp;
pid_t stats_id;
pthread_t *threads;
pthread_t console_thread;
pthread_t scheduler_thread;
int prev_thread_number;
int port,socket_conn,new_conn;
int shm;
int size;
int sf;
int scheduler_id;
int console_id;
int number_threads_to_exit;
int thread_to_exit;
int charswriten=0;
int exitscheduler=0, exitconsole=0;
int *thread_id;
int *exit_threads;
char req_buf[SIZE_BUF];
char buf_tmp[SIZE_BUF];
char buf[SIZE_BUF];
char filename[100];
char *wstats;
//MMF
int exitstats=0;
struct stat s;
int status,pagesmapped=1;
int old_size=0;
long pidstats;

int main(int argc, char ** argv){
 	signal(SIGINT,catch_ctrlc);
 	signal(SIGUSR1,sighandler_stats);
 	signal(SIGUSR2,sighandler_stats2);
 	buffer=create_buffer();
 	init();
	struct sockaddr_in client_name;
	socklen_t client_name_len = sizeof(client_name);

 	
	// Verify number of arguments
 	printf("Listening for HTTP requests on port %d\n",cfg->s_port);

	// Configure listening port
 	if ((socket_conn=fireup(cfg->s_port))==-1)	
 		exit(1);
 	else{
 		printf("Main PID: %ld\n",(long)getpid() );
		create_process();	
		while (1){	
			// Accept connection on socket

			if ( (new_conn = accept(socket_conn,(struct sockaddr *)&client_name,&client_name_len)) == -1 ) {
			printf("Error accepting connection\n");
			exit(1);
			}
			identify(new_conn);
			get_request(new_conn);
			sem_post(&reqsem);
		}
	}

}
void * worker(void * t){	
	int my_id = *((int*)t);
	while(1){

		sem_wait(&waitsem);
		if(thread_to_exit!=0){
			thread_to_exit--;
			printf("Thread %d exited\n",my_id);	
			pthread_exit(NULL);
		}
		#if DEBUG
		printf("[Thread Monitor]Thread %d is attending your request\n",my_id);
		#endif
		rptr aux_conn=(rptr)malloc(sizeof(request));
		aux_conn=select_request(buffer,aux_conn);
		send_page(aux_conn);
		sem_wait(&statssem);
		struct tm* end;
		time_t et_info;
		et_info=get_time();
		end=localtime(&et_info);
		strftime (aux_conn->et_info,100,"%d/%m/%Y %X",end);
		strcpy(statsreq->st_info,aux_conn->st_info);
		strcpy(statsreq->et_info,aux_conn->et_info);
		statsreq->s_time=aux_conn->s_time;
		statsreq->type=aux_conn->compressed;
		strcpy(statsreq->name,aux_conn->req);
		statsreq->e_time=clock();
		statsreq->count++;
		sem_post(&statssem);
		close(aux_conn->socket);
		free(aux_conn);
		printf("\n##############################################################################\n\n");
		if(thread_to_exit!=0){
			exit_threads[thread_to_exit-1]=my_id;
			thread_to_exit--;
			printf("Thread %d exited\n",my_id );	
			pthread_exit(NULL);
		}
	}



}

void * scheduler(void *t){

	
 	signal(SIGINT,catch_ctrlc); 	
 	signal(SIGUSR1,sighandler_stats);
 	signal(SIGUSR2,sighandler_stats2);


	while (1){	
		sem_wait(&reqsem);
		sem_wait(&sem);
		buffer_add(buffer,new_conn);
		sem_post(&sem);
		
		sem_post(&waitsem);
	
	if(exitscheduler==1){
		pthread_exit(NULL);
		}
	}

	pthread_exit(NULL);
}

rptr select_request(rptr buffer,rptr aux_conn){
	
	sem_wait(&sem);
	request *previous;
	request *actual;
	if(cfg->scheduling==0){
		actual=NULL;
		
	}

	else if(cfg->scheduling==1){
		find_buff_type(buffer,0,&previous,&actual);
	}
	else if(cfg->scheduling==2){
		find_buff_type(buffer,1,&previous,&actual);
	}

	if(actual!=NULL){	
		aux_conn->socket=actual->socket;
		aux_conn->s_time=actual->s_time;
		strcpy(aux_conn->st_info,actual->st_info);
		aux_conn->compressed=actual->compressed;
		strcpy(aux_conn->req,actual->req);

	}
	else{	
		aux_conn->socket=buffer->next->socket;
		aux_conn->s_time=buffer->next->s_time;
		strcpy(aux_conn->st_info,buffer->next->st_info);
		aux_conn->compressed=buffer->next->compressed;
		strcpy(aux_conn->req,buffer->next->req);
	
	}
	buffer_remove(buffer,aux_conn->socket);
	sem_post(&sem);
	return aux_conn;
}


//##################################################### CONNECTION AND READ RELATED FUNCTIONS ##############################################
// Processes request from client
void get_request(int socket)
{
	
	int i,j;
	int found_get;

	found_get=0;
	while ( read_line(socket,SIZE_BUF) > 0 ) {
		if(!strncmp(buf,GET_EXPR,strlen(GET_EXPR))) {
			// GET received, extract the requested page/script
			found_get=1;
			i=strlen(GET_EXPR);
			j=0;
			while( (buf[i]!=' ') && (buf[i]!='\0') )
				req_buf[j++]=buf[i++];
			req_buf[j]='\0';
		}

	}	

	// Currently only supports GET 
	if(!found_get) {
		printf("Request from client without a GET\n");
		//exit(1);
	}
	// If no particular page is requested then we consider htdocs/index.html
	if(!strlen(req_buf))
		sprintf(req_buf,"index.html");

	#if DEBUG
	printf("[Get_request] Client requested the following page: %s\n",req_buf);
	#endif

	return;
}


// Send message header (before html page) to client
void send_header(int socket)
{
	#if DEBUG
	printf("send_header: sending HTTP header to client\n");
	#endif
	sprintf(buf,HEADER_1);
	send(socket,buf,strlen(HEADER_1),0);
	sprintf(buf,SERVER_STRING);
	send(socket,buf,strlen(SERVER_STRING),0);
	sprintf(buf,HEADER_2);
	send(socket,buf,strlen(HEADER_2),0);

	return;
}


// Execute script in /cgi-bin
void execute_script(int socket)
{
	// Currently unsupported, return error code to client
	cannot_execute(socket);

	return;
}


// Send html page to client
void send_page(/*int socket,char* page*/ rptr aux_conn){
	FILE * fp;
	int isallowed=0;
	allowed *aux;
	aux=cfg->files->next;
	
	// Searchs for page in directory htdocs
	sprintf(buf_tmp,"htdocs/%s",aux_conn->req);

	#if DEBUG
	printf("[Send_page] Searching for %s\n",buf_tmp);
	#endif

	// Verifies if file exists
	if((fp=fopen(buf_tmp,"rt"))==NULL) {
		// Page not found, send error to client
		printf("[Send_page] Page %s not found, alerting client\n",buf_tmp);
		not_found(aux_conn->socket);
	}
	else {
		// Page found, send to client 
		if(aux_conn->compressed==1){
		if(strcmp(aux->name,"ALL")==0){
			isallowed=1;
		}
		else{
			while(aux!=NULL){
					if(strcmp(aux->name,aux_conn->req)==0){
						isallowed=1;
						break;
					}
					else{
					aux=aux->next;
					}
				}
			}

		if (isallowed){	
			pid_t zip=fork();
			if(zip==0){
				dup2(aux_conn->socket,fileno(stdout));
				#if DEBUG
				//printf("Page was compressed ! Decompressing...\n");
				#endif
				if(execlp("gunzip","gunzip","-c","-q",buf_tmp,(char*)NULL)==-1){
					perror("execl() failed");
				}
				return;
			}
		
		}
		else{
			not_found(aux_conn->socket);
			return;
		}
	}

	// First send HTTP header back to client
	send_header(aux_conn->socket);
	//printf("%s\n", );
	printf("[Send_page] Pending page %s to client\n",buf_tmp);
	while(fgets(buf_tmp,SIZE_BUF,fp))
		send(aux_conn->socket,buf_tmp,strlen(buf_tmp),0);
		// Close file
	fclose(fp);
	}
	return; 
}

// Identifies client (address and port) from socket
void identify(int socket)
{
	char ipstr[INET6_ADDRSTRLEN];
	socklen_t len;
	struct sockaddr_in *s;
	int port;
	struct sockaddr_storage addr;

	len = sizeof addr;
	getpeername(socket, (struct sockaddr*)&addr, &len);

	// Assuming only IPv4
	s = (struct sockaddr_in *)&addr;
	port = ntohs(s->sin_port);
	inet_ntop(AF_INET, &s->sin_addr, ipstr, sizeof ipstr);

	printf("[Identify] Received new request from %s port %d\n",ipstr,port);

	return;
}

// Reads a line (of at most 'n' bytes) from socket
int read_line(int socket,int n) 
{ 
	int n_read;
	int not_eol; 
	int ret;
	char new_char;

	n_read=0;
	not_eol=1;

	while (n_read<n && not_eol) {
		ret = read(socket,&new_char,sizeof(char));
		if (ret == -1) {
			printf("Error reading from socket (read_line)");
			return -1;
		}
		else if (ret == 0) {
			return 0;
		}
		else if (new_char=='\r') {
			not_eol = 0;
			// consumes next byte on buffer (LF)
			read(socket,&new_char,sizeof(char));
			continue;
		}		
		else {
			buf[n_read]=new_char;
			n_read++;
		}
	}

	buf[n_read]='\0';
	#if DEBUG
	//printf("read_line: new line read from client socket: %s\n",buf);
	#endif

	return n_read;
}


// Creates, prepares and returns new socket
int fireup(int port){
	int new_sock;
	struct sockaddr_in name;

	// Creates socket
	if ((new_sock = socket(PF_INET, SOCK_STREAM, 0))==-1) {
		printf("Error creating socket\n");
		return -1;
	}

	// Binds new socket to listening port 
	name.sin_family = AF_INET;
	name.sin_port = htons(port);
	name.sin_addr.s_addr = htonl(INADDR_ANY);
	if (bind(new_sock, (struct sockaddr *)&name, sizeof(name)) < 0) {
		printf("Error binding to socket\n");
		return -1;
	}

	// Starts listening on socket
	if (listen(new_sock, 5) < 0) {
		printf("Error listening to socket\n");
		return -1;
	}

	return(new_sock);
}


// Sends a 404 not found status message to client (page not found)
void not_found(int socket){
	sprintf(buf,"HTTP/1.0 404 NOT FOUND\r\n");
	send(socket,buf, strlen(buf), 0);
	sprintf(buf,SERVER_STRING);
	send(socket,buf, strlen(buf), 0);
	sprintf(buf,"Content-Type: text/html\r\n");
	send(socket,buf, strlen(buf), 0);
	sprintf(buf,"\r\n");
	send(socket,buf, strlen(buf), 0);
	sprintf(buf,"<HTML><TITLE>Not Found</TITLE>\r\n");
	send(socket,buf, strlen(buf), 0);
	sprintf(buf,"<BODY><P>Resource unavailable or nonexistent.\r\n");
	send(socket,buf, strlen(buf), 0);
	sprintf(buf,"</BODY></HTML>\r\n");
	send(socket,buf, strlen(buf), 0);

	return;
}


// Send a 5000 internal server error (script not configured for execution)
void cannot_execute(int socket){
	sprintf(buf,"HTTP/1.0 500 Internal Server Error\r\n");
	send(socket,buf, strlen(buf), 0);
	sprintf(buf,"Content-type: text/html\r\n");
	send(socket,buf, strlen(buf), 0);
	sprintf(buf,"\r\n");
	send(socket,buf, strlen(buf), 0);
	sprintf(buf,"<P>Error prohibited CGI execution.\r\n");
	send(socket,buf, strlen(buf), 0);

	return;
}


// Closes socket before closing
void catch_ctrlc(int sig){
	//Cleanup
	if(getpid()==pidstats){
			old_size = size;
			size =charswriten;
		    if (ftruncate(sf, size) != 0){
		        perror("Error extending file");
				close(sf);
				exit(1);
		    }
		    if ((wstats = mremap(wstats, old_size, size+1, MREMAP_MAYMOVE)) == MAP_FAILED){
		        perror("Error extending mapping");
		       	close(sf);
				exit(1);
		    }
		    strcat(wstats,"\n");

			munmap(wstats,size);
	allowed *ptr = cfg->files;
	fp=fopen("config_l.txt","w");
	fprintf(fp, "%d\n",cfg->s_port);
	fprintf(fp, "%d\n",cfg->scheduling);
	fprintf(fp, "%d\n",cfg->thread_pool);
	ptr=ptr->next;
		while(ptr != NULL){
			fprintf(fp,"%s;",ptr->name);
			ptr = ptr->next;
		}
	fclose(fp);
		shmdt((const void*)shm);
		shmctl( shm, IPC_RMID, NULL);
	
		//close(sf);
		free(threads);
		free(thread_id);
		if(close(socket_conn)==-1){
		perror("Can't close Socket");
		}
		printf("Server terminating\n"); 
		sem_destroy(&sem);
		sem_destroy(&semmmf);
		sem_destroy(&waitsem);
		sem_destroy(&statssem);
		sem_destroy(&reqsem);
	 	exit(0);
}



void init(){
	sem_init(&semmmf,0,1);

     	stats=(statistics*)malloc(sizeof(statistics));
     	#if DEBUG
     	if(stats!=NULL){
     		printf("Successfully created!\n");
     	}
     	#endif

		stats->n_compressed=0;
		stats->n_static=0;
	if((shm = shmget(1234,sizeof(statsreq),IPC_CREAT|0766))!=-1){
		statsreq = (statistics_request *)shmat(shm,NULL,0);
		statsreq->count=0;
	}
	else{
		perror("Can't create shared memory! ");
	}

	
	
	sem_init(&sem,0,1);
	sem_init(&waitsem,0,0);
	sem_init(&reqsem,0,0);
	sem_init(&statssem,0,1);
	initialConfig();
}

	//##################################################### SERVER REQUIREMENTS FUNCTIONS  ##############################################

void initialConfig(){
	cfg=(config*)malloc(sizeof(config));
	cfg->files=malloc(SIZE_BUF*sizeof(allowed));
	char line[SIZE_BUF];
	char split[2] = ";";
	int i;
	char *token;
	char type;
	cfg->files->next = NULL;
	allowed *ptr = cfg->files;
	allowed * new;
	i=0;
	printf("Do you wish to load the default configuration or the last one?\n(d/l)");
	scanf("%c",&type);
	if(type=='d'){
		strcpy(filename,"config_d.txt");
	}
	else{
		strcpy(filename,"config_l.txt");
	}

	if((fp=fopen(filename,"rt"))==NULL) {
		fp=fopen("config_d.txt","w+");
		cfg->s_port=50000;
		cfg->scheduling = 0;
		cfg->thread_pool = DEFAULT_THREADS;
		ptr->name= (char*)malloc(50*sizeof(char));
		strcpy (ptr->name, "ALL");


	}

	else {
		while(fscanf(fp,"%s",line) != EOF){

			if (i==0){		
				cfg->s_port=atoi(line);
			}
			else if (i==1){
				cfg->scheduling = atoi(line);
			}
			else if (i==2){
				
				cfg->thread_pool = atoi(line);
			}
			else if (i==3){
				token = strtok(line,split);
				while (token != NULL){
					new = (allowed *) malloc ( sizeof(allowed));
					new->name=(char*)malloc(50*sizeof(char));
					new->next = NULL;
					strcpy(new->name, token);
					ptr->next = new;
					ptr = new;				 
					token = strtok(NULL,split);		
				}
			}
			i++;
		}

	}

	fclose(fp);

}

	

void create_threads(int thread_id[],int flag){
	int aux;
	int cond=1;
	if(flag==0){
		threads= malloc((cfg->thread_pool)*sizeof(pthread_t));
		thread_id=malloc((cfg->thread_pool)*sizeof(int));
	}

	else if (flag==1){
		int i=0;
		threads=realloc(threads,(cfg->thread_pool)*sizeof(pthread_t));
		thread_id=realloc(thread_id,(cfg->thread_pool*sizeof(int)));
		aux=prev_thread_number;
		for(i=aux;i<cfg->thread_pool;i++){		
			pthread_create(&threads[i],NULL,worker,&thread_id[i]);
			thread_id[i]=i;
		}
		i=0;
		return;	
	}

	else{
		while(cond){
			if(thread_to_exit==0){
				for(int i=0;i<sizeof(exit_threads)/sizeof(exit_threads[0]);i++){
					printf("-----> %d\n",thread_to_exit );
					pthread_join(threads[i],NULL);
				}
				cond=0;
			
			}
		}
		free(exit_threads);	
		threads=realloc(threads,(cfg->thread_pool)*sizeof(pthread_t));
		thread_id=realloc(thread_id,(cfg->thread_pool)*sizeof(int));
		return;
	}

	for(int i=0;i<cfg->thread_pool;i++){
		thread_id[i] = i;
		
		if (pthread_create(&threads[i],NULL,worker,&thread_id[i]) != 0)
			perror("Error creating threads");	
	}

	scheduler_id = cfg->thread_pool+1;
	if (pthread_create(&scheduler_thread,NULL,scheduler, &scheduler_id) != 0)
		perror("Error creating scheduler");

	console_id=scheduler_id+1;
	if (pthread_create(&console_thread,NULL,create_namedpipe_server, &console_id) != 0)
		perror("Error creating console ");
}

void create_process(){
	if(((stats_id)=fork())==0){
	/*processo filho para as estatisticas*/
		pidstats=getpid();
		printf("Statitics Manager ID: %d\n",getpid());
		signal(SIGINT,SIG_IGN);
		stats_manager();
	}
	else if((stats_id)<0){
		perror("Can't create Statistics Manager");
	}
	else {
		create_threads(thread_id,0);

	}
}

void* create_namedpipe_server(void *t){	
	allowed *node = cfg->files;
	char* token;
	int fd,flag;

	if ((mkfifo(PIPE_NAME, O_CREAT|O_EXCL|0600)<0) && (errno!= EEXIST))  {     
		perror("Cannot create pipe: ");     
		exit(0);  
	} 

	if ((fd = open(PIPE_NAME, O_RDWR)) < 0) {     
			perror("Cannot open pipe for reading: ");     
			exit(0);  
	} 
	
	char command[100];

	while (1) {     
		read(fd, command, 100);
		printf("[SERVER] Received command %s \n", command);
		
		if(strcmp(command,"Closed")==0){
			printf("[Server] Console Closed\n");
		}

		if(strcmp(command,"scheduling")==0){
			read(fd, command, 100);
			printf("[SERVER] Received command %s\n",command);
			cfg->scheduling=atoi(command);
			printf("%d\n",cfg->scheduling);   
		}

		else if(strcmp(command,"threads")==0){
			prev_thread_number=cfg->thread_pool;
			read(fd, command, 100);
			if(atoi(command)>cfg->thread_pool){
				flag=1;
				cfg->thread_pool=atoi(command);
				printf("[SERVER] Received command %s\n",command);
			}
			else if(atoi(command)<cfg->thread_pool){
				flag=2;
				cfg->thread_pool=atoi(command);
				thread_to_exit=prev_thread_number-cfg->thread_pool;
				exit_threads=(int*)malloc(thread_to_exit*sizeof(int));
				for(int i=0;i<thread_to_exit;i++){
					sem_post(&waitsem);
				}
				printf("[SERVER] Received command %s\n",command);
				continue;
			}

			else if(atoi(command)==cfg->thread_pool){
				printf("The number of threads is already %s\n", command );
				command[0]='\0';
				continue;

			}
			create_threads(thread_id,flag);
			printf("Number of threads changed to %s\n",command );
		}

		else if(strcmp(command,"allowed")==0){
			read(fd,command,100);
			token=strtok(command,";");
			while(token!=NULL){
				allowed *new;
				new = (allowed *) malloc ( sizeof(allowed));
				if(new!=NULL){
					new->name=(char*)malloc(50*sizeof(char));
					new->next = NULL;
					strcpy(new->name, token);
				 	if(node!=NULL){
		    			while(node->next!=NULL){
		        			node=node->next;
		    			}
						node->next = new;
					}
					token=strtok(NULL,";");
				}
			}
			printf("Allowed files added!\n");
		}

	if(exitconsole==1){
		if(close(fd)==-1){
			perror("Cannot close socket");
		}
		pthread_exit(NULL);
		}
	}

	
}
		//##################################################### BUFFER RELATED FUNCTIONS ##############################################

rptr create_buffer(void) { 
	rptr aux;
	aux = (rptr) malloc(sizeof(request));
	if (aux != NULL) {
		aux->next = NULL;
	}
	return aux;
}

void find_buff(rptr buffer, int socket,rptr *previous, rptr *actual) {
	*previous = buffer;
	*actual = buffer->next;
	while ((*actual) != NULL && (*actual)->socket!=socket) {
		*previous = *actual;
		*actual = (*actual)->next;
	}

	if ((*actual) != NULL && (*actual)->socket != socket)
		*actual = NULL;
}

void find_buff_type(rptr buffer, int type,rptr *previous, rptr *actual) {
	*previous = buffer;
	*actual = buffer->next;
	while ((*actual) != NULL && (*actual)->compressed!=type) {
		*previous = *actual;
		*actual = (*actual)->next;
	}

	if ((*actual) != NULL && (*actual)->compressed != type)
		*actual = NULL;
}

void buffer_add(rptr buffer,int socket) {
	char* token;
	rptr node;
	rptr aux=buffer;
	node=(rptr)malloc(sizeof(request));
	if(node!=NULL){
		while(aux->next!=NULL){
			aux=aux->next;
		}

		strcpy(node->req,req_buf);
		token=strtok(req_buf,".");
		while(token!=NULL){
			if(strcmp(token,"gz")==0){
				node->compressed=1;
				break;
			}
			else{
				node->compressed=0;
			}
			token=strtok(NULL,".");
		}
		struct tm* start;
		time_t st_info;
		st_info=get_time();
		start=localtime(&st_info);
		strftime (node->st_info,100,"%d/%m/%Y %X",start);
			
		node->s_time=clock();
		node->socket=socket;
		node->next=NULL;
		aux->next=node;


	}
}


void buffer_remove(rptr buffer,int socket){
	request *previous;
	request *actual;
	find_buff(buffer,socket,&previous,&actual);
	if(actual!=NULL){
		previous->next=actual->next;
		free(actual);
	}
}

void stats_manager(){
	signal(SIGUSR1,sighandler_stats);
 	signal(SIGUSR2,sighandler_stats2);
 	signal(SIGINT,catch_ctrlc);
	sem_init(&semmmf,0,1);
	int total=0;
	double static_time=0;
	double compressed_time=0;
	
	sf = open("server.log", O_RDWR|O_CREAT|O_TRUNC,FILE_MODE);
	if(sf<0){
		printf("Error open file\n");
		exit(1);
		}	
	 	status=fstat(sf, & s);
	if(status <0) {// To obtain file size 
		perror("Error in fstat");
		exit(1);
	}

	size=s.st_size;
	printf("---->%d\n", size);
	if((wstats=mmap(0,size+1,PROT_READ|PROT_WRITE, MAP_SHARED,sf,0))==(caddr_t)-1){
		perror("Error in mmap\n");
		exit(1);
	}

	old_size = size;
	size += sysconf(_SC_PAGE_SIZE);

    if (ftruncate(sf, size) != 0){
        perror("Error extending file");
		close(sf);
		exit(1);
    }

    if ((wstats = mremap(wstats, old_size, size, MREMAP_MAYMOVE)) == MAP_FAILED){
        perror("Error extending mapping");
       	close(sf);
		exit(1);
    }
	while(1){
		sem_wait(&statssem);
			

		if(total<statsreq->count){
		//print file;
			char* towrite =(char*)malloc(200*sizeof(char));
			sem_wait(&semmmf);	
			if(statsreq->type==0){
				sprintf(towrite,"Normal %s %s %s\n",statsreq->name,statsreq->st_info,statsreq->et_info);
				stats->n_static++;
				total++;
				static_time+=((float)(statsreq->e_time-statsreq->s_time)/CLOCKS_PER_SEC*1000);
				stats->at_static=static_time/stats->n_static;
			}

		else{
			sprintf(towrite,"Compressed %s %s %s\n",statsreq->name,statsreq->st_info,statsreq->et_info);
			stats->n_compressed++;
			total++;
			compressed_time+=((float)(statsreq->e_time-statsreq->s_time)/CLOCKS_PER_SEC*1000);				
			stats->at_compressed=compressed_time/stats->n_compressed;;
			}

		if(charswriten+strlen(towrite)<=size){
			charswriten+=strlen(towrite);
			strcat(wstats,towrite);
			msync(wstats,size,MS_SYNC);
			towrite[0]='\n';
		}

		else{
			printf("Remapping File !\n");
			old_size = size;
			size += sysconf(_SC_PAGE_SIZE);

		    if (ftruncate(sf, size) != 0){
		        perror("Error extending file");
				close(sf);
				exit(1);
		    }

		    if ((wstats = mremap(wstats, old_size, size, MREMAP_MAYMOVE)) == MAP_FAILED){
		        perror("Error extending mapping");
		       	close(sf);
				exit(1);
		    }

		charswriten+=strlen(towrite);
		strcat(wstats,towrite);
		msync(wstats,size,MS_SYNC);
		towrite[0]='\n';
		}
				
		sem_post(&semmmf);
		}
	
	sem_post(&statssem);
	}

}

time_t get_time(){
	time_t rawtime;
	time(&rawtime);    
   	
   	return rawtime;
}

void sighandler_stats(int sig){
	printf("Static Files: %d\n",stats->n_static );
	printf("Compressed Files: %d\n",stats->n_compressed);
	printf("Static Average time: %.3f ms\n",stats->at_static );	
	printf("Compressed Average time: %.3f ms\n",stats->at_compressed);
}

void sighandler_stats2(int sig){

	stats->n_static = 0;
	stats->n_compressed = 0;
	stats->at_static = 0;
	stats->at_compressed = 0;
	printf("Statistics reseted!\n");
}
